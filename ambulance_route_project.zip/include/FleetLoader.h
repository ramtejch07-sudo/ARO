#ifndef FLEETLOADER_H
#define FLEETLOADER_H

#include <string>
#include "Manager.h"

/**
 * @brief Load hospitals and ambulances from a JSON file into a Manager.
 *
 * Expected format (see data/fleet.json):
 * {
 *   "hospitals":  [ {"name": "...", "lat": 0.0, "lng": 0.0, "capacity": 5} ],
 *   "ambulances": [ {"id": 1, "lat": 0.0, "lng": 0.0, "capacity": 2} ]
 * }
 *
 * @param path    Path to the JSON file
 * @param manager Manager to fill
 * @param error   Receives a human-readable message on failure
 * @return true on success
 */
bool loadFleet(const std::string& path, Manager& manager, std::string& error);

#endif // FLEETLOADER_H
