#ifndef ROUTEOPTIMIZER_H
#define ROUTEOPTIMIZER_H

#include "Graph.h"
#include "Route.h"
#include "Location.h"
#include "Ambulance.h"
#include "EmergencyCall.h"
#include <vector>
#include <map>
#include <memory>

/**
 * @class RouteOptimizer
 * @brief Optimizes routes for ambulances
 * 
 * Provides algorithms for:
 * - Finding shortest/fastest paths
 * - Assigning ambulances to calls
 * - Optimizing routes for multiple simultaneous calls
 * - Vehicle Routing Problem (VRP) solutions
 */
class RouteOptimizer {
private:
    Graph* roadNetwork;                         ///< Pointer to road network graph
    std::map<std::pair<int,int>, Route> routeCache;  ///< Cache for computed routes

public:
    /**
     * @brief Constructor
     * @param network Pointer to road network graph
     */
    explicit RouteOptimizer(Graph* network);
    
    // Destructor
    /**
     * @brief Destructor
     */
    ~RouteOptimizer();
    
    // Basic pathfinding
    /**
     * @brief Find shortest path between two locations
     * @param start Starting location
     * @param end Ending location
     * @return Route object representing shortest path
     */
    Route findShortestPath(Location start, Location end);
    
    /**
     * @brief Find fastest route (considers time, not just distance)
     * @param start Starting location
     * @param end Ending location
     * @return Route object representing fastest path
     */
    Route findFastestRoute(Location start, Location end);
    
    /**
     * @brief Find multiple alternative routes
     * @param start Starting location
     * @param end Ending location
     * @param maxRoutes Maximum number of alternative routes
     * @return Vector of Route objects
     */
    std::vector<Route> getAllAlternativeRoutes(Location start, 
                                               Location end, 
                                               int maxRoutes = 3);
    
    // Ambulance assignment
    /**
     * @brief Assign the optimal ambulance to an emergency call
     * 
     * Selects the nearest available ambulance considering:
     * - Distance to call location
     * - Ambulance availability
     * - Response time
     * 
     * @param call Emergency call to assign
     * @param ambulances Vector of available ambulances
     * @return Pointer to assigned ambulance, nullptr if none available
     */
    Ambulance* assignOptimalAmbulance(EmergencyCall& call, 
                                      std::vector<Ambulance>& ambulances);
    
    /**
     * @brief Get nearest ambulances by distance
     * @param call Emergency call
     * @param ambulances Available ambulances
     * @param count Number of nearest to return
     * @return Vector of ambulance pointers
     */
    std::vector<Ambulance*> getNearestAmbulances(EmergencyCall& call,
                                                  std::vector<Ambulance>& ambulances,
                                                  int count = 3);
    
    /**
     * @brief Get ambulances sorted by ETA
     * @param call Emergency call
     * @param ambulances Available ambulances
     * @param count Number to return
     * @return Vector of ambulance pointers sorted by ETA
     */
    std::vector<Ambulance*> getAmbulancesByETA(EmergencyCall& call,
                                               std::vector<Ambulance>& ambulances,
                                               int count = 3);
    
    // Multi-call optimization
    /**
     * @brief Optimize routes for multiple calls
     * 
     * Solves Vehicle Routing Problem for assigning multiple calls
     * to available ambulances
     * 
     * @param calls Vector of emergency calls
     * @param ambulances Vector of available ambulances
     * @return Vector of optimized routes
     */
    std::vector<Route> optimizeMultipleCalls(std::vector<EmergencyCall>& calls,
                                             std::vector<Ambulance>& ambulances);
    
    /**
     * @brief Solve VRP using Nearest Neighbor heuristic
     * @param calls Emergency calls
     * @param ambulances Available ambulances
     * @return Vector of assigned routes
     */
    std::vector<Route> solveVRPNearestNeighbor(std::vector<EmergencyCall>& calls,
                                               std::vector<Ambulance>& ambulances);
    
    /**
     * @brief Solve VRP using Greedy algorithm
     * @param calls Emergency calls
     * @param ambulances Available ambulances
     * @return Vector of assigned routes
     */
    std::vector<Route> solveVRPGreedy(std::vector<EmergencyCall>& calls,
                                      std::vector<Ambulance>& ambulances);
    
    // Caching
    /**
     * @brief Clear route cache
     */
    void clearCache();
    
    /**
     * @brief Get cache statistics
     * @return Number of cached routes
     */
    int getCacheSize() const { return routeCache.size(); }
    
    // Utility
    /**
     * @brief Print optimizer status
     */
    void print() const;
};

#endif // ROUTEOPTIMIZER_H
