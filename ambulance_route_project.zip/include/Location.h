#ifndef LOCATION_H
#define LOCATION_H

#include <cmath>
#include <iostream>
#include <iomanip>

/**
 * @class Location
 * @brief Represents a geographic location with latitude and longitude
 * 
 * This class handles coordinate storage and distance calculations
 * using the Haversine formula for accurate geographic distances.
 */
class Location {
private:
    double latitude;    ///< Latitude in degrees (-90 to 90)
    double longitude;   ///< Longitude in degrees (-180 to 180)

public:
    /**
     * @brief Default constructor
     * @param lat Latitude (default: 0.0)
     * @param lon Longitude (default: 0.0)
     */
    Location(double lat = 0.0, double lon = 0.0);
    
    // Getters
    /**
     * @return Current latitude
     */
    double getLatitude() const { return latitude; }
    
    /**
     * @return Current longitude
     */
    double getLongitude() const { return longitude; }
    
    // Setters
    /**
     * @brief Set latitude value
     * @param lat Latitude value
     */
    void setLatitude(double lat) { latitude = lat; }
    
    /**
     * @brief Set longitude value
     * @param lon Longitude value
     */
    void setLongitude(double lon) { longitude = lon; }
    
    /**
     * @brief Calculate distance to another location using Haversine formula
     * @param other Target location
     * @return Distance in meters
     */
    double getDistance(const Location& other) const;
    
    /**
     * @brief Check equality of two locations
     * @param other Location to compare
     * @return true if coordinates are identical
     */
    bool operator==(const Location& other) const;
    
    /**
     * @brief Print location information to console
     */
    void print() const;
};

#endif // LOCATION_H
