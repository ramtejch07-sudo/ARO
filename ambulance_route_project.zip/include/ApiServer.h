#ifndef APISERVER_H
#define APISERVER_H

#include <mutex>
#include <string>
#include "httplib.h"
#include "Manager.h"

/**
 * @class ApiServer
 * @brief HTTP server exposing the fleet as JSON and serving the web frontend.
 *
 * Routes:
 *   GET /api/health              server status and counts
 *   GET /api/hospitals           all hospitals
 *   GET /api/ambulances          all ambulances
 *   GET /api/ambulances/{id}     one ambulance
 *   GET /                        static files from the web root (frontend/)
 */
class ApiServer {
public:
    ApiServer(Manager& manager, std::string webRoot);

    /**
     * @brief Start listening (blocks until the server stops)
     * @return false if the port could not be bound
     */
    bool run(const std::string& host, int port);

private:
    void registerRoutes();

    Manager& manager_;
    std::string webRoot_;
    std::mutex mutex_;          ///< Guards manager_ across request threads
    httplib::Server server_;
};

#endif // APISERVER_H
