# Ambulance Route Optimization

An object-oriented C++17 project that tracks ambulances on a live map and assigns them to emergency calls.

## Project layout

```
Ambulance-Route-Optimization/
├── src/              C++ implementation (.cpp)
├── include/          C++ headers (.h)
├── frontend/         Web dashboard: index.html, app.js, style.css
├── data/             Data files: fleet.json (hospitals + ambulances), maps/ (road networks)
├── tests/            Unit tests
├── third_party/      Header-only libraries: httplib.h (HTTP server), nlohmann/json.hpp
├── docs/             Documentation
├── CMakeLists.txt    Build configuration
└── .gitignore
```

## Build

Requires a C++17 compiler (g++ 9+, clang++, or MSVC 2019+) and CMake 3.10+.

```bash
cmake -S . -B build
cmake --build build
```

Windows (Visual Studio):

```powershell
cmake -S . -B build
cmake --build build --config Release
```

## Run the tests

```bash
ctest --test-dir build --output-on-failure
```

(Older CMake: `cd build && ctest --output-on-failure`.)

## Run the server

Run from the project root so the default paths (`data/fleet.json`, `frontend/`) resolve:

```bash
./build/ambulance_server                 # Linux / macOS
.\build\Debug\ambulance_server.exe       # Windows (Visual Studio; path may be build\Release)
```

Then open http://127.0.0.1:8080 in a browser.

Options: `--port 8080`, `--host 127.0.0.1`, `--data data/fleet.json`, `--web frontend`.

### API

| Method | Path | Returns |
|---|---|---|
| GET | `/api/health` | Server status and counts |
| GET | `/api/hospitals` | All hospitals with free slots |
| GET | `/api/ambulances` | All ambulances with position and status |
| GET | `/api/ambulances/{id}` | One ambulance (404 if unknown) |

Quick check:

```bash
curl http://127.0.0.1:8080/api/ambulances
```

## Data

Hospitals and ambulances are defined in `data/fleet.json`. The coordinates are sample values near central Ho Chi Minh City. Replace them with your own city's locations; the app does not depend on the city.

## Status

| Week | Feature | State |
|---|---|---|
| 1-2 | Core classes (Location, Hospital, Ambulance, EmergencyCall, Route, Graph, RouteOptimizer, Manager) | Done |
| 3 | HTTP server + JSON API | Done |
| 4 | Leaflet map showing hospitals and ambulances | Done |
| 5 | Simulator moves ambulances along routes | Planned |
| 6 | Create emergency calls; assign nearest ambulance; draw route | Planned |
| 7 | Driver page sends real GPS position | Planned |
| 8 | Assignment strategies (nearest / ETA) and call queue | Planned |
| 9+ | Road routing via OSRM, testing, polish | Planned |

## Third-party code

- [cpp-httplib](https://github.com/yhirose/cpp-httplib) (MIT) v0.63.0
- [nlohmann/json](https://github.com/nlohmann/json) (MIT) v3.11.3
- [Leaflet](https://leafletjs.com) (BSD-2) and OpenStreetMap tiles, loaded in the browser
