#define _USE_MATH_DEFINES  // MSVC: enables M_PI
#include "Location.h"
#include <cmath>
#include <iomanip>

// Constants for Haversine formula
const double EARTH_RADIUS_METERS = 6371000.0; // Earth's radius in meters

Location::Location(double lat, double lon) 
    : latitude(lat), longitude(lon) {}

double Location::getDistance(const Location& other) const {
    // Haversine formula for great circle distance
    double lat1 = latitude * M_PI / 180.0;      // Convert to radians
    double lat2 = other.latitude * M_PI / 180.0;
    double lon1 = longitude * M_PI / 180.0;
    double lon2 = other.longitude * M_PI / 180.0;
    
    double dlat = lat2 - lat1;
    double dlon = lon2 - lon1;
    
    double a = std::sin(dlat / 2.0) * std::sin(dlat / 2.0) +
               std::cos(lat1) * std::cos(lat2) * 
               std::sin(dlon / 2.0) * std::sin(dlon / 2.0);
    
    double c = 2.0 * std::atan2(std::sqrt(a), std::sqrt(1.0 - a));
    
    return EARTH_RADIUS_METERS * c;
}

bool Location::operator==(const Location& other) const {
    // Consider locations equal if coordinates match to 6 decimal places
    return (std::abs(latitude - other.latitude) < 1e-6) &&
           (std::abs(longitude - other.longitude) < 1e-6);
}

void Location::print() const {
    std::cout << std::fixed << std::setprecision(6);
    std::cout << "Location (" << latitude << ", " << longitude << ")" << std::endl;
}
