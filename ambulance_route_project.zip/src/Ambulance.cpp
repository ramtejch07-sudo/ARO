#include "Ambulance.h"
#include <iostream>

Ambulance::Ambulance(int id, Location loc, int cap)
    : id(id), status(AmbulanceStatus::AVAILABLE), 
      currentLocation(loc), capacity(cap) {
    if (cap < 1) {
        std::cerr << "Warning: Ambulance capacity should be at least 1" << std::endl;
    }
}

double Ambulance::getDistance(const Location& loc) const {
    return currentLocation.getDistance(loc);
}

std::string Ambulance::getStatusString() const {
    switch (status) {
        case AmbulanceStatus::AVAILABLE:
            return "AVAILABLE";
        case AmbulanceStatus::EN_ROUTE:
            return "EN_ROUTE";
        case AmbulanceStatus::AT_HOSPITAL:
            return "AT_HOSPITAL";
        case AmbulanceStatus::BUSY:
            return "BUSY";
        case AmbulanceStatus::MAINTENANCE:
            return "MAINTENANCE";
        default:
            return "UNKNOWN";
    }
}

void Ambulance::print() const {
    std::cout << "Ambulance ID: " << id << std::endl;
    std::cout << "  Status: " << getStatusString() << std::endl;
    std::cout << "  Location: (" << currentLocation.getLatitude() << ", " 
              << currentLocation.getLongitude() << ")" << std::endl;
    std::cout << "  Capacity: " << capacity << " patients" << std::endl;
}
