#include "Manager.h"
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include <fstream>
#include <iomanip>

Manager::Manager(Graph* network) 
    : optimizer(new RouteOptimizer(network)) {}

Manager::~Manager() {
    // optimizer will be deleted automatically via unique_ptr
}

void Manager::addHospital(const Hospital& hospital) {
    hospitals.push_back(hospital);
}

Hospital& Manager::getHospital(int index) {
    if (index >= 0 && index < (int)hospitals.size()) {
        return hospitals[index];
    }
    throw std::out_of_range("Hospital index out of range");
}

void Manager::addAmbulance(const Ambulance& ambulance) {
    ambulances.push_back(ambulance);
}

Ambulance* Manager::getAmbulance(int id) {
    for (auto& amb : ambulances) {
        if (amb.getId() == id) {
            return &amb;
        }
    }
    return nullptr;
}

int Manager::getAvailableAmbulanceCount() const {
    int count = 0;
    for (const auto& amb : ambulances) {
        if (amb.isAvailable()) {
            count++;
        }
    }
    return count;
}

int Manager::getBusyAmbulanceCount() const {
    return ambulances.size() - getAvailableAmbulanceCount();
}

bool Manager::processEmergencyCall(EmergencyCall call) {
    totalCalls++;
    
    // Try to assign an ambulance
    Ambulance* assigned = optimizer->assignOptimalAmbulance(call, ambulances);
    
    if (assigned) {
        // Successful assignment
        call.setStatus(CallStatus::ASSIGNED);
        assigned->setStatus(AmbulanceStatus::EN_ROUTE);
        
        assignedAmbulances[call.getId()] = assigned;
        successfulAssignments++;
        
        std::cout << "Call #" << call.getId() << " assigned to Ambulance #" 
                  << assigned->getId() << std::endl;
        return true;
    } else {
        // Queue the call
        call.setStatus(CallStatus::PENDING);
        pendingCalls.push(call);
        
        std::cout << "Call #" << call.getId() << " queued (no ambulances available)" << std::endl;
        return false;
    }
}

void Manager::processEmergencyCalls(std::vector<EmergencyCall>& calls) {
    for (auto& call : calls) {
        processEmergencyCall(call);
    }
}

void Manager::processPendingCalls() {
    while (!pendingCalls.empty()) {
        EmergencyCall call = pendingCalls.front();
        
        Ambulance* assigned = optimizer->assignOptimalAmbulance(call, ambulances);
        
        if (assigned) {
            pendingCalls.pop();
            call.setStatus(CallStatus::ASSIGNED);
            assigned->setStatus(AmbulanceStatus::EN_ROUTE);
            assignedAmbulances[call.getId()] = assigned;
            successfulAssignments++;
        } else {
            // Still no available ambulances
            break;
        }
    }
}

void Manager::completeCall(int ambulanceId, int hospitalId) {
    Ambulance* amb = getAmbulance(ambulanceId);
    if (!amb) {
        std::cerr << "Ambulance #" << ambulanceId << " not found" << std::endl;
        return;
    }
    
    if (hospitalId >= 0 && hospitalId < (int)hospitals.size()) {
        hospitals[hospitalId].addAmbulance(amb);
        amb->setStatus(AmbulanceStatus::AVAILABLE);
        
        // Try to assign pending calls
        processPendingCalls();
    } else {
        std::cerr << "Hospital index out of range" << std::endl;
    }
}

void Manager::updateAmbulanceStatuses() {
    // Update ambulance statuses based on time and tasks
    for (auto& amb : ambulances) {
        if (amb.isBusy()) {
            // Simulate movement or status change
            // In real implementation, would check GPS data
        }
    }
}

void Manager::monitorAndReassign() {
    // Check for optimization opportunities
    // Reassign if better routes found
    
    // For now, just try to process pending calls
    processPendingCalls();
}

bool Manager::isSystemHealthy() const {
    // Verify all assignments are valid
    for (const auto& [callId, amb] : assignedAmbulances) {
        if (!amb) {
            std::cerr << "Invalid ambulance assignment for call #" << callId << std::endl;
            return false;
        }
    }
    
    return true;
}

double Manager::getAverageResponseTime() const {
    if (successfulAssignments == 0) {
        return 0.0;
    }
    return totalResponseTime / successfulAssignments;
}

double Manager::getSuccessfulAssignmentRate() const {
    if (totalCalls == 0) {
        return 0.0;
    }
    return (double)successfulAssignments / totalCalls * 100.0;
}

void Manager::print() const {
    std::cout << "=== Ambulance Management System ===" << std::endl;
    std::cout << "Hospitals: " << hospitals.size() << std::endl;
    std::cout << "Ambulances: " << ambulances.size() << std::endl;
    std::cout << "  Available: " << getAvailableAmbulanceCount() << std::endl;
    std::cout << "  Busy: " << getBusyAmbulanceCount() << std::endl;
    std::cout << "Pending Calls: " << pendingCalls.size() << std::endl;
    std::cout << "Total Calls Processed: " << totalCalls << std::endl;
    std::cout << "Successful Assignments: " << successfulAssignments << std::endl;
}

void Manager::printDetailedReport() const {
    std::cout << "\n=== Detailed System Report ===" << std::endl;
    
    std::cout << "\nHospitals:" << std::endl;
    for (size_t i = 0; i < hospitals.size(); i++) {
        std::cout << "  [" << i << "] ";
        hospitals[i].print();
    }
    
    std::cout << "\nAmbulances:" << std::endl;
    for (const auto& amb : ambulances) {
        std::cout << "  [" << amb.getId() << "] ";
        amb.print();
    }
    
    std::cout << "\nPending Calls: " << pendingCalls.size() << std::endl;
}

void Manager::printStatistics() const {
    std::cout << "\n=== System Statistics ===" << std::endl;
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Total Calls: " << totalCalls << std::endl;
    std::cout << "Successful Assignments: " << successfulAssignments << std::endl;
    std::cout << "Success Rate: " << getSuccessfulAssignmentRate() << "%" << std::endl;
    std::cout << "Average Response Time: " << getAverageResponseTime() << " seconds" << std::endl;
    std::cout << "Current Pending Calls: " << pendingCalls.size() << std::endl;
}

void Manager::exportStatistics(const std::string& filename) const {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << filename << std::endl;
        return;
    }
    
    file << "Ambulance Route Optimization System - Statistics Report" << std::endl;
    file << "=======================================================" << std::endl;
    file << std::endl;
    
    file << "Total Hospitals: " << hospitals.size() << std::endl;
    file << "Total Ambulances: " << ambulances.size() << std::endl;
    file << "Available Ambulances: " << getAvailableAmbulanceCount() << std::endl;
    file << "Busy Ambulances: " << getBusyAmbulanceCount() << std::endl;
    file << std::endl;
    
    file << "Total Calls Processed: " << totalCalls << std::endl;
    file << "Successful Assignments: " << successfulAssignments << std::endl;
    file << std::fixed << std::setprecision(2);
    file << "Success Rate: " << getSuccessfulAssignmentRate() << "%" << std::endl;
    file << "Average Response Time: " << getAverageResponseTime() << " seconds" << std::endl;
    file << "Pending Calls: " << pendingCalls.size() << std::endl;
    
    file.close();
    std::cout << "Statistics exported to " << filename << std::endl;
}
