#include "ApiServer.h"

#include <iostream>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

namespace {

json ambulanceToJson(const Ambulance& a) {
    return json{
        {"id", a.getId()},
        {"status", a.getStatusString()},
        {"available", a.isAvailable()},
        {"lat", a.getCurrentLocation().getLatitude()},
        {"lng", a.getCurrentLocation().getLongitude()},
        {"capacity", a.getCapacity()}
    };
}

json hospitalToJson(const Hospital& h, int id) {
    return json{
        {"id", id},
        {"name", h.getName()},
        {"lat", h.getLatitude()},
        {"lng", h.getLongitude()},
        {"capacity", h.getTotalCapacity()},
        {"availableSlots", h.getAvailableCapacity()}
    };
}

void sendJson(httplib::Response& res, const json& body, int status = 200) {
    res.status = status;
    res.set_content(body.dump(), "application/json");
}

} // namespace

ApiServer::ApiServer(Manager& manager, std::string webRoot)
    : manager_(manager), webRoot_(std::move(webRoot)) {}

void ApiServer::registerRoutes() {
    server_.Get("/api/health", [this](const httplib::Request&, httplib::Response& res) {
        std::lock_guard<std::mutex> lock(mutex_);
        sendJson(res, json{
            {"status", "ok"},
            {"hospitals", manager_.getHospitalCount()},
            {"ambulances", manager_.getAmbulanceCount()}
        });
    });

    server_.Get("/api/hospitals", [this](const httplib::Request&, httplib::Response& res) {
        std::lock_guard<std::mutex> lock(mutex_);
        json list = json::array();
        auto& hospitals = manager_.getHospitals();
        for (size_t i = 0; i < hospitals.size(); ++i) {
            list.push_back(hospitalToJson(hospitals[i], static_cast<int>(i)));
        }
        sendJson(res, json{{"hospitals", list}});
    });

    server_.Get("/api/ambulances", [this](const httplib::Request&, httplib::Response& res) {
        std::lock_guard<std::mutex> lock(mutex_);
        json list = json::array();
        for (const auto& a : manager_.getAmbulances()) {
            list.push_back(ambulanceToJson(a));
        }
        sendJson(res, json{{"ambulances", list}});
    });

    server_.Get(R"(/api/ambulances/(\d+))", [this](const httplib::Request& req, httplib::Response& res) {
        std::lock_guard<std::mutex> lock(mutex_);
        int id = std::stoi(req.matches[1]);
        Ambulance* amb = manager_.getAmbulance(id);
        if (!amb) {
            sendJson(res, json{{"error", "ambulance not found"}, {"id", id}}, 404);
            return;
        }
        sendJson(res, ambulanceToJson(*amb));
    });
}

bool ApiServer::run(const std::string& host, int port) {
    registerRoutes();

    if (!server_.set_mount_point("/", webRoot_)) {
        std::cerr << "Warning: web root '" << webRoot_
                  << "' not found; run from the project folder or pass --web\n";
    }

    std::cout << "Serving http://" << host << ":" << port << "  (Ctrl+C to stop)\n";
    return server_.listen(host, port);
}
