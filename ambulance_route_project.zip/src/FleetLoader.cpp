#include "FleetLoader.h"

#include <fstream>
#include <set>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

bool loadFleet(const std::string& path, Manager& manager, std::string& error) {
    std::ifstream in(path);
    if (!in) {
        error = "cannot open file: " + path;
        return false;
    }

    try {
        json doc;
        in >> doc;

        for (const auto& h : doc.at("hospitals")) {
            manager.addHospital(Hospital(h.at("lat").get<double>(),
                                         h.at("lng").get<double>(),
                                         h.at("name").get<std::string>(),
                                         h.at("capacity").get<int>()));
        }

        std::set<int> seenIds;
        for (const auto& a : doc.at("ambulances")) {
            int id = a.at("id").get<int>();
            if (!seenIds.insert(id).second) {
                error = "duplicate ambulance id " + std::to_string(id);
                return false;
            }
            Location loc(a.at("lat").get<double>(), a.at("lng").get<double>());
            manager.addAmbulance(Ambulance(id, loc, a.value("capacity", 2)));
        }
    } catch (const std::exception& e) {
        error = e.what();
        return false;
    }
    return true;
}
