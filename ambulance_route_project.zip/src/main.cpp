#include <iostream>
#include <string>

#include "ApiServer.h"
#include "FleetLoader.h"
#include "Graph.h"
#include "Manager.h"

int main(int argc, char** argv) {
    std::string host = "127.0.0.1";
    std::string dataPath = "data/fleet.json";
    std::string webRoot = "frontend";
    int port = 8080;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        bool hasValue = (i + 1 < argc);
        if (arg == "--host" && hasValue)      host = argv[++i];
        else if (arg == "--data" && hasValue) dataPath = argv[++i];
        else if (arg == "--web" && hasValue)  webRoot = argv[++i];
        else if (arg == "--port" && hasValue) port = std::stoi(argv[++i]);
        else {
            std::cerr << "Usage: ambulance_server [--host H] [--port P] [--data FILE] [--web DIR]\n";
            return 1;
        }
    }

    // Road network is not used by the API yet (Week 5+ will connect it).
    Graph roadNetwork(0);
    Manager manager(&roadNetwork);

    std::string error;
    if (!loadFleet(dataPath, manager, error)) {
        std::cerr << "Failed to load " << dataPath << ": " << error << "\n";
        return 1;
    }
    std::cout << "Loaded " << manager.getHospitalCount() << " hospitals and "
              << manager.getAmbulanceCount() << " ambulances from " << dataPath << "\n";

    ApiServer server(manager, webRoot);
    if (!server.run(host, port)) {
        std::cerr << "Could not start server on " << host << ":" << port
                  << " (port in use?)\n";
        return 1;
    }
    return 0;
}
