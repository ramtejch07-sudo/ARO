// Core unit tests. Uses CHECK instead of assert so it still runs in Release builds.
#include <cmath>
#include <iostream>
#include <vector>

#include "Graph.h"
#include "Location.h"

static int failures = 0;
#define CHECK(cond)                                                      \
    do {                                                                 \
        if (!(cond)) {                                                   \
            std::cerr << "FAILED line " << __LINE__ << ": " #cond "\n";  \
            ++failures;                                                  \
        }                                                                \
    } while (0)

int main() {
    // Haversine: one degree of longitude at the equator is about 111.2 km.
    Location a(0.0, 0.0), b(0.0, 1.0);
    CHECK(std::fabs(a.getDistance(b) - 111195.0) < 100.0);
    CHECK(a.getDistance(a) < 1e-6);

    // Dijkstra picks the shorter two-hop path (2500) over the direct edge (3000).
    Graph g(3);
    g.addEdge(0, 1, 1000);
    g.addEdge(1, 2, 1500);
    g.addEdge(0, 2, 3000);
    std::vector<int> path = g.dijkstra(0, 2);
    CHECK((path == std::vector<int>{0, 1, 2}));

    // Unreachable node returns an empty path.
    Graph h(3);
    h.addEdge(0, 1, 100);
    CHECK(h.dijkstra(0, 2).empty());

    if (failures == 0) {
        std::cout << "All core tests passed\n";
        return 0;
    }
    std::cerr << failures << " test(s) failed\n";
    return 1;
}
