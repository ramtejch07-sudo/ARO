// Live tracking dashboard: draws hospitals once, then polls ambulance positions.
const POLL_INTERVAL_MS = 2000;

const STATUS_COLORS = {
    AVAILABLE: '#2e9e5b',
    EN_ROUTE: '#f0a202',
    BUSY: '#d64545',
    AT_HOSPITAL: '#2f80ed',
    MAINTENANCE: '#8a94a0',
};
const DEFAULT_COLOR = '#8a94a0';

const map = L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors',
}).addTo(map);

const hospitalLayer = L.layerGroup().addTo(map);
const ambulanceMarkers = new Map();   // ambulance id -> Leaflet marker
const connection = document.getElementById('connection');

function setConnection(ok, text) {
    connection.textContent = text;
    connection.className = 'pill ' + (ok ? 'ok' : 'err');
}

// Text is always set with textContent so server data cannot inject HTML.
function li(text, meta) {
    const item = document.createElement('li');
    const label = document.createElement('span');
    label.textContent = text;
    const info = document.createElement('span');
    info.className = 'meta';
    info.textContent = meta;
    item.append(label, info);
    return item;
}

async function getJson(url) {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error(`${url} returned ${response.status}`);
    return response.json();
}

async function loadHospitals() {
    const { hospitals } = await getJson('/api/hospitals');
    hospitalLayer.clearLayers();
    const list = document.getElementById('hospital-list');
    list.replaceChildren();

    const points = [];
    for (const h of hospitals) {
        const marker = L.marker([h.lat, h.lng], {
            icon: L.divIcon({ className: 'hospital-icon', html: '🏥', iconSize: [28, 28] }),
        }).bindPopup(`<strong>${escapeHtml(h.name)}</strong><br>Free slots: ${h.availableSlots} / ${h.capacity}`);
        hospitalLayer.addLayer(marker);
        points.push([h.lat, h.lng]);
        list.appendChild(li(h.name, `${h.availableSlots}/${h.capacity} free`));
    }

    if (points.length) map.fitBounds(points, { padding: [40, 40] });
}

function ambulanceMarker(a) {
    const color = STATUS_COLORS[a.status] || DEFAULT_COLOR;
    return L.circleMarker([a.lat, a.lng], {
        radius: 9,
        color: '#ffffff',
        weight: 2,
        fillColor: color,
        fillOpacity: 1,
    }).bindTooltip(`Ambulance ${a.id}`, { permanent: false });
}

async function refreshAmbulances() {
    try {
        const { ambulances } = await getJson('/api/ambulances');
        const seen = new Set();

        for (const a of ambulances) {
            seen.add(a.id);
            const color = STATUS_COLORS[a.status] || DEFAULT_COLOR;
            const existing = ambulanceMarkers.get(a.id);
            if (existing) {
                existing.setLatLng([a.lat, a.lng]);
                existing.setStyle({ fillColor: color });
                existing.setTooltipContent(`Ambulance ${a.id} · ${a.status}`);
            } else {
                const marker = ambulanceMarker(a).addTo(map);
                marker.setTooltipContent(`Ambulance ${a.id} · ${a.status}`);
                ambulanceMarkers.set(a.id, marker);
            }
        }

        // Remove markers for ambulances that no longer exist
        for (const id of [...ambulanceMarkers.keys()]) {
            if (!seen.has(id)) {
                map.removeLayer(ambulanceMarkers.get(id));
                ambulanceMarkers.delete(id);
            }
        }

        const list = document.getElementById('ambulance-list');
        list.replaceChildren(...ambulances.map(a =>
            li(`Ambulance ${a.id}`, `${a.status} · ${a.lat.toFixed(4)}, ${a.lng.toFixed(4)}`)
        ));

        const time = new Date().toLocaleTimeString();
        setConnection(true, `Live · updated ${time}`);
    } catch (err) {
        console.error(err);
        setConnection(false, 'Connection lost, retrying…');
    }
}

function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
}

async function start() {
    try {
        await loadHospitals();
    } catch (err) {
        console.error(err);
        map.setView([10.776, 106.70], 13);   // fallback view if hospitals fail
        setConnection(false, 'Could not load hospitals');
    }
    await refreshAmbulances();
    setInterval(refreshAmbulances, POLL_INTERVAL_MS);
}

start();
